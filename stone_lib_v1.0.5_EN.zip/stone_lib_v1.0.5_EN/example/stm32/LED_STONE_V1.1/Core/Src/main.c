/* ��stone���ڿ����ĵƴ�demo */
/* 				2022.2.22          */

/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "ws2812.h"
#include "stone.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim3;
DMA_HandleTypeDef hdma_tim3_ch4_up;

UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_rx;
DMA_HandleTypeDef hdma_usart1_tx;


/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART1_UART_Init2(void);
static void MX_DMA_Init(void);
//static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
RGB_COLOR USER_RGB_COLOR;

extern unsigned char STONE_RX_BUF[200];
extern unsigned short STONE_RX_CNT;
extern unsigned char receive_over_flage;
extern unsigned char transport_over_flage;
extern recive_group STONER;

enum led_ctrl {switch_white = 0,
								switch_red,
								switch_green,
								switch_blue,
								white_lum,
								red_lum,
								green_lum,
								blue_lum,
								blink1,
								blink2,
								blink3,
								blink4,
};
int led_ctrl_cnt = 0;
const char *led_function[] = {		"switch_white",
														"switch_red",
														"switch_green",
														"switch_blue",
														"white_lum",
														"red_lum",
														"green_lum",
														"blue_lum",
														"blink1",
														"blink2",
														"blink3",
														"blink4",
														"0"};

unsigned char USER_R=0,USER_G=0,USER_B=0,COLOR_TYPE=0,COLOR_DIR=0;
uint16_t times=0,k,q;
unsigned char blink_type=0; 		//Define the blink type
unsigned char BLINK_2=0;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
	MX_DMA_Init();
//	MX_TIM3_Init();
	if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_4)) 
	MX_USART1_UART_Init2();  								//RS232 Initiallize
	else 
 	MX_USART1_UART_Init(); 									//TTL Initiallize
  
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
		if(receive_over_flage == 1)
		{
			receive_parse();      //Serial port Reception Parsing
			led_ctrl_cnt = 0;
			
			/* Parse the pressed button selection function */
			for (led_ctrl_cnt = 0; led_ctrl_cnt<=blink4; led_ctrl_cnt++)
			{
				if (strcmp(led_function[led_ctrl_cnt],(const char *)STONER.widget)==0)
					break;
			}

			switch (led_ctrl_cnt)
			{
				case switch_white:
				{
					blink_type=0;
					if (STONER.value == 1)
					{
						set_image("image", "white_led", "light_white");
						set_value("label", "white_lum", "100", "%02d");
						USER_RGB_COLOR.C_WHITE=0xFF;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_WHITE, USER_RGB_COLOR.C_WHITE, USER_RGB_COLOR.C_WHITE);
					}
					else if (STONER.value == 0)
					{
						set_image("image", "white_led", "light_off");
						set_value("label", "white_lum", "0", "%02d");
						USER_RGB_COLOR.C_WHITE=0x00;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_WHITE, USER_RGB_COLOR.C_WHITE, USER_RGB_COLOR.C_WHITE);
					}
					break;
				}
				case switch_red:
				{
					blink_type=0;
					if (STONER.value == 1)
					{
						set_image("image", "red_led", "light_red");
						set_value("label", "red_lum", "100", "%02d");
						USER_RGB_COLOR.C_RED=0xFF;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					}
					else if (STONER.value == 0)
					{
						set_image("image", "red_led", "light_off");
						set_value("label", "red_lum", "0", "%02d");
						USER_RGB_COLOR.C_RED=0x00;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					}
					
					break;
				}
				case switch_green:
				{
					blink_type=0;
					if (STONER.value == 1)
					{
						set_image("image", "green_led", "light_green");
						set_value("label", "green_lum", "100", "%02d");
						USER_RGB_COLOR.C_GREEN=0xFF;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					}
					else if (STONER.value == 0)
					{
						set_image("image", "green_led", "light_off");
						set_value("label", "green_lum", "0", "%02d");
						USER_RGB_COLOR.C_GREEN=0x00;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					}
					break;
				}
				case switch_blue: 
				{
					blink_type=0;
					if (STONER.value == 1)
					{
						set_image("image", "blue_led", "light_blue");
						set_value("label", "blue_lum", "100", "%02d");
						USER_RGB_COLOR.C_BLUE=0xFF;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					}
					else if (STONER.value == 0)
					{
						set_image("image", "blue_led", "light_off");
						set_value("label", "blue_lum", "0", "%02d");
						USER_RGB_COLOR.C_BLUE=0x00;
						RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					}
					break;
				}
				case white_lum: 
				{
					blink_type=0;
					if ((unsigned char)STONER.float_value == 1)
					{
						set_image("image", "white_led", "light_white");
					}
					else if ((unsigned char)STONER.float_value == 0)
					{
						set_image("image", "white_led", "light_off");
					}
					USER_RGB_COLOR.C_WHITE=(unsigned char)STONER.float_value;
					RGB_LED_Write_24Bits(USER_RGB_COLOR.C_WHITE, USER_RGB_COLOR.C_WHITE, USER_RGB_COLOR.C_WHITE);
					break;
				}
				case red_lum: 
				{
					blink_type=0;
					if ((unsigned char)STONER.float_value == 1)
					{
						set_image("image", "red_led", "light_red");
					}
					else if ((unsigned char)STONER.float_value == 0)
					{
						set_image("image", "red_led", "light_off");
					}
					USER_RGB_COLOR.C_RED=(unsigned char)STONER.float_value;
					RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					break;
				}
				case green_lum: 
				{
					blink_type=0;
					if ((unsigned char)STONER.float_value == 1)
					{
						set_image("image", "green_led", "light_green");
					}
					else if ((unsigned char)STONER.float_value == 0)
					{
						set_image("image", "green_led", "light_off");
					}
					USER_RGB_COLOR.C_GREEN=(unsigned char)STONER.float_value;
					RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					break;
				}
				case blue_lum: 
				{
					blink_type=0;
					if ((unsigned char)STONER.float_value == 1)
					{
						set_image("image", "blue_led", "light_blue");
					}
					else if ((unsigned char)STONER.float_value == 0)
					{
						set_image("image", "blue_led", "light_off");
					}
					USER_RGB_COLOR.C_BLUE=(unsigned char)STONER.float_value;
					RGB_LED_Write_24Bits(USER_RGB_COLOR.C_RED, USER_RGB_COLOR.C_GREEN, USER_RGB_COLOR.C_BLUE);
					break;
				}
				case blink1: 
				{
					blink_type=1;
					RGB_LED_Write_24Bits(0, 0, 0);
					times=USER_R=USER_G=USER_B=COLOR_TYPE=COLOR_DIR=0;
					break;
				}
				case blink2: 
				{
					blink_type=2;
					RGB_LED_Write_24Bits(0, 0, 0);
					times=USER_R=USER_G=USER_B=COLOR_TYPE=COLOR_DIR=0;
					break;
				}
				case blink3: 
				{
					blink_type=3;
					RGB_LED_Write_24Bits(0, 0, 0);
					times=USER_R=USER_G=USER_B=COLOR_TYPE=COLOR_DIR=0;
					break;
				}
				case blink4: 
				{
					blink_type=4;
					RGB_LED_Write_24Bits(0, 0, 0);
					times=USER_R=USER_G=USER_B=COLOR_TYPE=COLOR_DIR=0;
					break;
				}
				default:
				{
					receive_over_flage = 0;
					break;
				}
			}
			receive_over_flage = 0;
    /* USER CODE BEGIN 3 */
		}
		else
		{
			if(blink_type==1)                //Blink1 function, turns on the breathing light. Beyond the switch function.
			{
				times++;
				if(times>=14)
				{
					HAL_Delay(1);
					times=0;
					if(COLOR_DIR==0)
					{
						if(COLOR_TYPE==0)
						{
							USER_R++;
							USER_G=0;
							USER_B=0;
						}	
						else if(COLOR_TYPE==1)
						{
							USER_R=0;
							USER_G++;
							USER_B=0;
						}
						else if(COLOR_TYPE==2)
						{
							USER_R=0;
							USER_G=0;
							USER_B++;
						}
						else if(COLOR_TYPE==3)
						{
							USER_R++;
							USER_G++;
							USER_B=0;
						}
						else if(COLOR_TYPE==4)
						{
							USER_R=0;
							USER_G++;
							USER_B++;
						}
						else if(COLOR_TYPE==5)
						{
							USER_R++;
							USER_G=0;
							USER_B++;
						}
						if((USER_R>=250)||(USER_G>=250)||(USER_B>=250))
						{
							COLOR_DIR=1;
						}
					}
					else
					{
						if(COLOR_TYPE==0)
						{
							USER_R--;
							USER_G=0;
							USER_B=0;
						}	
						else if(COLOR_TYPE==1)
						{
							USER_R=0;
							USER_G--;
							USER_B=0;
						}
						else if(COLOR_TYPE==2)
						{
							USER_R=0;
							USER_G=0;
							USER_B--;
						}
						else if(COLOR_TYPE==3)
						{
							USER_R--;
							USER_G--;
							USER_B=0;
						}
						else if(COLOR_TYPE==4)
						{
							USER_R=0;
							USER_G--;
							USER_B--;
						}
						else if(COLOR_TYPE==5)
						{
							USER_R--;
							USER_G=0;
							USER_B--;
						}
						if((USER_R==0x02)||(USER_G==0x02)||(USER_B==0x02))
						{
							COLOR_DIR=0;
							COLOR_TYPE++;
							if(COLOR_TYPE>5)
								COLOR_TYPE=0;
						}
					}
					RGB_LED_Write_24Bits(USER_R,USER_G,USER_B);
				}
				HAL_Delay(1);
			}
			else if(blink_type==2)              //Blink2 mode
			{
				k++;
				if(k>=150)
				{
					k=0;
					q=200;
					{
						BLINK_2++;
						if(BLINK_2>8)BLINK_2=0;
					}			
						if(BLINK_2==0)
							RGB_LED_Write_24Bits(q,0,0);
						else if(BLINK_2==1)
							RGB_LED_Write_24Bits(0,q,0);
						else if(BLINK_2==2)
							RGB_LED_Write_24Bits(0,0,q);
						else if(BLINK_2==3)
							RGB_LED_Write_24Bits(q,q,0);
						else if(BLINK_2==4)
							RGB_LED_Write_24Bits(0,q,q);
						else if(BLINK_2==5)
							RGB_LED_Write_24Bits(q,0,q); 
						else if(BLINK_2==6)
							RGB_LED_Write_24Bits(q-100,q,0);
						else if(BLINK_2==7)
							RGB_LED_Write_24Bits(0,q-80,q);
						else if(BLINK_2==8)
							RGB_LED_Write_24Bits(q,0,q-120); 
						else if(BLINK_2==9)
							RGB_LED_Write_24Bits(40,q-100,q-70);
						else if(BLINK_2==10)
							RGB_LED_Write_24Bits(q,100,q-80); 
					
				}
				HAL_Delay(1);
			}
			else if(blink_type==3)
			{
				k++;
				if(k>=1000)
				{
					k=0;
					{
						BLINK_2++;
						if(BLINK_2>5)BLINK_2=0;
					}			
					{
						if(BLINK_2==0)
							RGB_LED_Write_24Bits(q,0,0);
						else if(BLINK_2==1)
							RGB_LED_Write_24Bits(0,q,0);
						else if(BLINK_2==2)
							RGB_LED_Write_24Bits(0,0,q);
						else if(BLINK_2==3)
							RGB_LED_Write_24Bits(q,q,0);
						else if(BLINK_2==4)
							RGB_LED_Write_24Bits(0,q,q);
						else if(BLINK_2==5)
							RGB_LED_Write_24Bits(q,0,q); 
					}
				}
				HAL_Delay(1);
			}
			else if(blink_type==4)
			{
				k++;
				if(k>=500)
				{
						k=0;
						q=0;
						BLINK_2++;
						if(BLINK_2>5)BLINK_2=0;
				}		
				q++;
				if(q>=250)q=0;
						if(BLINK_2==0)
							RGB_LED_Write_24Bits(q,0,0);
						else if(BLINK_2==1)
							RGB_LED_Write_24Bits(0,q,0);
						else if(BLINK_2==2)
							RGB_LED_Write_24Bits(0,0,q);
						else if(BLINK_2==3)
							RGB_LED_Write_24Bits(q,q,0);
						else if(BLINK_2==4)
							RGB_LED_Write_24Bits(0,q,q);
						else if(BLINK_2==5)
							RGB_LED_Write_24Bits(q,0,q); 
						HAL_Delay(2);
			}
			
		}
  /* USER CODE END 3 */
	}
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	serial_receive();
	stone_uart_read(USER_UART);
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if (stone_uart_get_flag(USER_UART))
	transport_over_flage = 1;
}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */


static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
	stone_uart_read(USER_UART);
  /* USER CODE END USART1_Init 2 */

}


void MX_USART1_UART_Init2(void)
{

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;

  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_TXINVERT_INIT|UART_ADVFEATURE_RXINVERT_INIT
                              |UART_ADVFEATURE_DATAINVERT_INIT|UART_ADVFEATURE_SWAP_INIT;
  huart1.AdvancedInit.TxPinLevelInvert = UART_ADVFEATURE_TXINV_ENABLE;
  huart1.AdvancedInit.RxPinLevelInvert = UART_ADVFEATURE_RXINV_ENABLE;
  huart1.AdvancedInit.DataInvert = UART_ADVFEATURE_DATAINV_DISABLE;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
	stone_uart_read(USER_UART);
  /* USER CODE END USART1_Init 2 */
}
/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel2_3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(WS2812_GPIO_Port, WS2812_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : UART_SEL_Pin */
  GPIO_InitStruct.Pin = UART_SEL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(UART_SEL_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : WS2812_Pin */
  GPIO_InitStruct.Pin = WS2812_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(WS2812_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
