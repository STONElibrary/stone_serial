#ifndef __WS2812_LED_H__
#define __WS2812_LED_H__

#include "stdint.h"

#define PIXEL_NUM  30
#define NUM (24*PIXEL_NUM + 30)
#define WS1 61
#define WS0 28

extern uint16_t send_Buf[NUM];

typedef  struct __RGB_COLOR
{
	unsigned char C_RED;
	unsigned char C_GREEN;
	unsigned char C_BLUE;
	unsigned char C_WHITE;
	
	unsigned char C_RED_FLAG;
	unsigned char C_GREEN_FLAG;
	unsigned char C_BLUE_FLAG;
}RGB_COLOR;

void WS_Load(void);
void RGB_LED_Write_24Bits(uint8_t n_R, uint8_t n_G, uint8_t n_B);
void WS_CloseAll(void);

#endif
