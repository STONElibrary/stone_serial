#ifndef __WS2812_H
#define __WS2812_H
#include "stm32f0xx_hal.h"


#define RGB_LED_HIGH  GPIOA->BSRR = (uint32_t)GPIO_PIN_7;
//#define RGB_LED_HIGH HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,GPIO_PIN_SET)
#define RGB_LED_LOW  	GPIOA->BRR = (uint32_t)GPIO_PIN_7;
//#define RGB_LED_LOW HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,GPIO_PIN_RESET)
#define WS_HIGH 0XF8
#define WS_LOW  0XE0



#define RED_COLOR   	 0x81
#define GREEN_COLOR  	 0x82
#define BLUE_COLOR 		 0x83
#define WHITE_COLOR 	 0x84
#define LED_ALL_ONOFF  0x85

#define RED_COLOR_ADD   	 0x4B
#define RED_COLOR_SUB   	 0x9C

#define GREEN_COLOR_ADD  	 0x4D
#define GREEN_COLOR_SUB  	 0x4E

#define BLUE_COLOR_ADD 		 0x41
#define BLUE_COLOR_SUB  	 0x42

#define WHITE_COLOR_ADD 	 0x49
#define WHITE_COLOR_SUB 	 0x4A

#define BLINK1         0x86        
#define BLINK2         0x87  
#define BLINK3         0x88  
#define BLINK4         0x89  
 
#define LightOn      0x00
#define LightOff     0x01

#define LED_QUIT1 	 0x7A


typedef  struct __RGB_COLOR
{
	unsigned char C_RED;
	unsigned char C_GREEN;
	unsigned char C_BLUE;
	unsigned char C_WHITE;
	
	unsigned char C_RED_FLAG;
	unsigned char C_GREEN_FLAG;
	unsigned char C_BLUE_FLAG;
}RGB_COLOR;

void RGB_LED_Write_24Bits(unsigned char red,unsigned char green,unsigned char blue);
void RGB_LED_Write_24Bits1(unsigned char red,unsigned char green,unsigned char blue);
void RGB_LED_Write_24Bits_effect(unsigned char red,unsigned char green,unsigned char blue);
void RGB_LED_Write_24Bits_Efect(unsigned char red,unsigned char green,unsigned char blue);
void RGB_LED_RST(void);
extern unsigned char PIXEL_NUM;
#endif /* __WS2812_H */
